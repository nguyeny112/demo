
<?php $__env->startComponent('mail::message'); ?>
# Welcome to SMP Shop
Hello <?php echo e($user->name); ?>


Welcome to our SMP Shop, hope you enjoying our services. 
Have a nice day.

<?php $__env->startComponent('mail::button', ['url' => route('public.index.index')]); ?>
Visit our Shop
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
