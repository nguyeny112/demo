        @include('templates.public.header')
        @yield('main-content')  
         @include('templates.public.leftbar')
        @include('templates.public.footer')