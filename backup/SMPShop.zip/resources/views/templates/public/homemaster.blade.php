        @include('templates.public.header')
        @yield('main-content') 
        @include('templates.public.footer')